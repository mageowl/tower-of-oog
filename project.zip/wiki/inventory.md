# Inventory
The inventory is a group of 4 [item slots|items] shared across all members of your [party|creatures/humans.md].
Any item can be put here, including [consumables|items/consumables]
