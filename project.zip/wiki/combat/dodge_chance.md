# Dodge Chance
The dodge chance (dc) of a creature is the chance that a given [attack|combat/damage.md] will miss.
Magic damage will always hit, no matter the defender's dodge chance.

dodge chance = agil / 10
