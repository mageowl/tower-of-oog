# Action Points
Action points (ap) are a measurement of how much time a creature has left in its turn.
Most creatures have 2 or 3 maximum action points, and none can have less than 1.

max ap = 2 + wis / 3 (rounded up)
