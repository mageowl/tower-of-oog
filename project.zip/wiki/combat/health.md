# Health
Each creature has a number of hit points. When you take [damage|combat/damage.md] your health decreases. If it ever reaches 0, you die and become a [grave|props/grave.md].
Some consumables like [health potions|items/health_potion.md] heal damage you have taken. Your hit points can never go over your hit point maximum.

max hp = 7 + might
