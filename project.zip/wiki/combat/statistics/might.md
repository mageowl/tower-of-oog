# Might
Might is a [statistic|combat/statistics] that repersents an creature's physical strength. It affects melee attack damage and [max health|combat/health.md].

max hp = 7 + might
