# Statistics
A statistic is a numerical value that is added to some rolls & damage totals. For most creatures, they start somewhere between -2 and +3.
