# Wisdom
Wisdom is a [statistic|combat/statistics] that repersents an creature's mental power and concentration. It affects magic duration and [action points|combat/action_points.md].

max ap = 2 + wis / 3 (rounded up)
