# Agility
Agility is a [statistic|combat/statistics] that repersents a creature's dexterity and acrobatic ability. It affects ranged accuracy and [dodge chance|combat/dodge_chance.md].

dodge chance = agil / 10
