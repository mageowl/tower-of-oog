# Damage
There are three kinds of damage: melee, ranged, and magic.

Melee damage
- Dealt by most weapons
- Random
2-4 M. dmg

Ranged damage
- Dealt by some weapons
- Constant, but has a chance to miss, in addition to the defender's dodge chance
12 R. dmg (20%)

Magic damage
- Dealt by status effects over time
- Not affected by dodge chance
2 Mg. dmg per turn
