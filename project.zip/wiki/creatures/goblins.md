# Goblins
Nasty little thingies. They hate [humans|creatures/humans.md].
