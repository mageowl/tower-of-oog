# Keyboard
This game is mostly controlled with the mouse, but there are a few keyboard shortcuts to keep in mind:

- Alt+Click: Open wiki page corrisponding to object or number under cursor.
