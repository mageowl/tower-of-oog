# Example wiki
[link|creatures/humans.md]
number font: _10/10_ hp
