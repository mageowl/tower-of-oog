# Items
Items are objects that your characters can pick up and use.
To move them around, click once on a slot to pick up, and click again to set it down.
